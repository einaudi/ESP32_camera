#include "http_api.h"

#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_spiffs.h"

#include <string.h>
#include <stdlib.h>

#include "app_config.h"
#include "camera_worker.h"
#include "analysis.h"
#include "esp_camera.h"   // fmt2jpg

#define SET_PIXEL_BGR(buf, idx, b, g, r) \
    do { buf[idx+0] = (b); buf[idx+1] = (g); buf[idx+2] = (r); } while(0)


static const char *TAG = "http_api";

static httpd_handle_t g_api_server = NULL;

uint16_t roi_x0, roi_y0, roi_dx, roi_dy;

// ========================
// SPIFFS mount
// ========================
static esp_err_t spiffs_mount(void) {
    esp_vfs_spiffs_conf_t conf = {
        .base_path = "/spiffs",
        .partition_label = "spiffs",
        .max_files = 8,
        .format_if_mount_failed = false,
    };
    esp_err_t ret = esp_vfs_spiffs_register(&conf);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "SPIFFS mount failed: %s", esp_err_to_name(ret));
        return ret;
    }
    size_t total = 0, used = 0;
    ret = esp_spiffs_info("spiffs", &total, &used);
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "SPIFFS mounted: total=%u, used=%u", (unsigned)total, (unsigned)used);
    } else {
        ESP_LOGW(TAG, "esp_spiffs_info failed: %s", esp_err_to_name(ret));
    }
    return ESP_OK;
}

// ========================
// Helpers
// ========================
static const char *get_mime_type(const char *path) {
    if (strstr(path, ".html")) return "text/html";
    if (strstr(path, ".js")) return "application/javascript";
    if (strstr(path, ".css")) return "text/css";
    if (strstr(path, ".png")) return "image/png";
    if (strstr(path, ".jpg")) return "image/jpeg";
    if (strstr(path, ".ico")) return "image/x-icon";
    return "text/plain";
}

static esp_err_t send_file(httpd_req_t *req, const char *filepath) {
    FILE *f = fopen(filepath, "rb");
    if (!f) {
        ESP_LOGW(TAG, "File not found: %s", filepath);
        httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "File not found");
        return ESP_OK;
    }
    httpd_resp_set_type(req, get_mime_type(filepath));
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    char buf[1024];
    size_t read_bytes;
    while ((read_bytes = fread(buf, 1, sizeof(buf), f)) > 0) {
        esp_err_t res = httpd_resp_send_chunk(req, buf, read_bytes);
        if (res != ESP_OK) {
            ESP_LOGW(TAG, "send_chunk failed (%s)", esp_err_to_name(res));
            fclose(f);
            httpd_resp_send_chunk(req, NULL, 0);
            return res;
        }
    }
    fclose(f);
    httpd_resp_send_chunk(req, NULL, 0);
    return ESP_OK;
}

static void grayscale_to_rgb888(uint8_t *gray,
                                uint8_t *rgb,
                                int width,
                                int height)
{
    for (int i = 0; i < width * height; i++) {
        uint8_t v = gray[i];
        rgb[3*i + 0] = v; // R
        rgb[3*i + 1] = v; // G
        rgb[3*i + 2] = v; // B
    }
}

static void draw_roi_rect_rgb(uint8_t *rgb,
                              int img_w,
                              int img_h,
                              const roi_t *roi)
{
    int x0 = roi->x0;
    int y0 = roi->y0;
    int x1 = x0 + roi->dx - 1;
    int y1 = y0 + roi->dy - 1;

    // clamp (na wszelki wypadek)
    if (x1 >= img_w) x1 = img_w - 1;
    if (y1 >= img_h) y1 = img_h - 1;

    // górna i dolna krawędź
    for (int x = x0; x <= x1; x++) {
        int top = (y0 * img_w + x) * 3;
        int bot = (y1 * img_w + x) * 3;

        if (roi->enabled) {
            SET_PIXEL_BGR(rgb, top, 0, 0, 255);
            SET_PIXEL_BGR(rgb, bot, 0, 0, 255);
        }
        else {
            SET_PIXEL_BGR(rgb, top, 255, 0, 0);
            SET_PIXEL_BGR(rgb, bot, 255, 0, 0);
        }
    }

    // lewa i prawa krawędź
    for (int y = y0; y <= y1; y++) {
        int left  = (y * img_w + x0) * 3;
        int right = (y * img_w + x1) * 3;

        if (roi->enabled) {
            SET_PIXEL_BGR(rgb, left, 0, 0, 255);
            SET_PIXEL_BGR(rgb, right, 0, 0, 255);
        }
        else {
            SET_PIXEL_BGR(rgb, left, 255, 0, 0);
            SET_PIXEL_BGR(rgb, right, 255, 0, 0);
        }
    }
}

static void draw_centroid_rgb(uint8_t *rgb,
                              int img_w,
                              int img_h,
                              const centroid_t *c,
                              int color)
{
    if (!c->valid)
        return;

    int cx = (int)(c->x + 0.5f);
    int cy = (int)(c->y + 0.5f);

    const int size = 5;

    for (int dx = -size; dx <= size; dx++) {
        int x = cx + dx;
        int y = cy;
        if (x >= 0 && x < img_w && y >= 0 && y < img_h) {
            int p = (y * img_w + x) * 3;
            if(color == 0) SET_PIXEL_BGR(rgb, p, 255, 0, 0);
            else if(color == 1)SET_PIXEL_BGR(rgb, p, 0, 255, 0);
            else SET_PIXEL_BGR(rgb, p, 0, 0, 255);
        }
    }

    for (int dy = -size; dy <= size; dy++) {
        int x = cx;
        int y = cy + dy;
        if (x >= 0 && x < img_w && y >= 0 && y < img_h) {
            int p = (y * img_w + x) * 3;
            if(color == 0) SET_PIXEL_BGR(rgb, p, 255, 0, 0);
            else if(color == 1)SET_PIXEL_BGR(rgb, p, 0, 255, 0);
            else SET_PIXEL_BGR(rgb, p, 0, 0, 255);
        }
    }
}


// ========================
// HTTP handlers
// ========================
static esp_err_t index_handler(httpd_req_t *req) {
    // / -> /spiffs/index.html
    return send_file(req, "/spiffs/index.html");
}

static esp_err_t appjs_handler(httpd_req_t *req) {
    return send_file(req, "/spiffs/app.js");
}

static esp_err_t style_handler(httpd_req_t *req) {
    return send_file(req, "/spiffs/style.css");
}

static esp_err_t status_handler(httpd_req_t *req) {
    const char *resp = "OK\n";
    httpd_resp_set_type(req, "text/plain");
    httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static esp_err_t control_handler(httpd_req_t *req) {
    char query[256];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Missing query");
        return ESP_OK;
    }
    ESP_LOGI(TAG, "CONTROL: %s", query);

    // Camera settings
    int queued = 0;
    char val_str[32];
    if (httpd_query_key_value(query, "exposure", val_str, sizeof(val_str)) == ESP_OK) {
        if (!queue_cam_cmd(CAM_CMD_SET_EXPOSURE, atoi(val_str))) {
            httpd_resp_send_err(req, 503, "Queue full");
            return ESP_OK;
        }
        queued++;
    }
    if (httpd_query_key_value(query, "gain", val_str, sizeof(val_str)) == ESP_OK) {
        if (!queue_cam_cmd(CAM_CMD_SET_GAIN, atoi(val_str))) {
            httpd_resp_send_err(req, 503, "Queue full");
            return ESP_OK;
        }
        queued++;
    }
    if (httpd_query_key_value(query, "brightness", val_str, sizeof(val_str)) == ESP_OK) {
        if (!queue_cam_cmd(CAM_CMD_SET_BRIGHTNESS, atoi(val_str))) {
            httpd_resp_send_err(req, 503, "Queue full");
            return ESP_OK;
        }
        queued++;
    }
    if (httpd_query_key_value(query, "contrast", val_str, sizeof(val_str)) == ESP_OK) {
        if (!queue_cam_cmd(CAM_CMD_SET_CONTRAST, atoi(val_str))) {
            httpd_resp_send_err(req, 503, "Queue full");
            return ESP_OK;
        }
        queued++;
    }
    if (httpd_query_key_value(query, "roi_enable", val_str, sizeof(val_str)) == ESP_OK) {
        g_roi.enabled = atoi(val_str) ? true : false;
        g_config.roi_enabled = atoi(val_str);
        config_save(&g_config);
        queued++;
    }
    // Failed
    if (queued == 0) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "No known params");
        return ESP_OK;
    }
    
    char resp[64];
    snprintf(resp, sizeof(resp), "OK queued=%d\n", queued);
    httpd_resp_set_type(req, "text/plain");
    httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static esp_err_t roi_handler(httpd_req_t *req) {
    char query[256];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Missing query");
        return ESP_OK;
    }
    ESP_LOGI(TAG, "ROI: %s", query);

    // ROI
    char val_str[32];
    bool roi_param_all = true;
    // ROI dimensions
    if (httpd_query_key_value(query, "x0", val_str, sizeof(val_str)) == ESP_OK) {
        roi_x0 = atoi(val_str);
    }
    else roi_param_all = false;
    if (httpd_query_key_value(query, "y0", val_str, sizeof(val_str)) == ESP_OK) {
        roi_y0 = atoi(val_str);
    }
    else roi_param_all = false;
    if (httpd_query_key_value(query, "dx", val_str, sizeof(val_str)) == ESP_OK) {
        roi_dx = atoi(val_str);
    }
    else roi_param_all = false;
    if (httpd_query_key_value(query, "dy", val_str, sizeof(val_str)) == ESP_OK) {
        roi_dy = atoi(val_str);
    }
    else roi_param_all = false;

    if (roi_param_all) {
        xSemaphoreTake(g_image_mutex, portMAX_DELAY);
        bool ok = roi_validate_and_set(
            roi_x0, roi_y0, roi_dx, roi_dy
        );
        xSemaphoreGive(g_image_mutex);

        if (!ok) {
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                "Invalid ROI parameters");
            return ESP_FAIL;
        }
    }
    // Failed
    else {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Not enough ROI parameters");
        return ESP_OK;
    }
    
    char resp[64];
    snprintf(resp, sizeof(resp), "OK");
    httpd_resp_set_type(req, "text/plain");
    httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static esp_err_t target_handler(httpd_req_t *req) {
    char query[256];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Missing query");
        return ESP_OK;
    }
    ESP_LOGI(TAG, "TARGET: %s", query);

    // Target settings
    int queued = 0;
    char val_str[32];
    if (httpd_query_key_value(query, "x", val_str, sizeof(val_str)) == ESP_OK) {
        g_target.x = atoi(val_str);
        g_config.target_x = atoi(val_str);
        config_save(&g_config);
        queued++;
    }
    if (httpd_query_key_value(query, "y", val_str, sizeof(val_str)) == ESP_OK) {
        g_target.y = atoi(val_str);
        g_config.target_y = atoi(val_str);
        config_save(&g_config);
        queued++;
    }
    if (httpd_query_key_value(query, "tol", val_str, sizeof(val_str)) == ESP_OK) {
        g_error.tol2 = atof(val_str)*atof(val_str);
        g_config.target_tolerance = atof(val_str);
        config_save(&g_config);
        queued++;
    }
    // Failed
    if (queued == 0) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "No known params");
        return ESP_OK;
    }

    char resp[64];
    snprintf(resp, sizeof(resp), "OK queued=%d\n", queued);
    httpd_resp_set_type(req, "text/plain");
    httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static esp_err_t preview_handler(httpd_req_t *req)
{
    if (!g_image_snapshot.valid) {
        httpd_resp_send_500(req);
        return ESP_FAIL;
    }

    uint8_t *jpg_buf = NULL;
    size_t jpg_len = 0;

    xSemaphoreTake(g_image_mutex, portMAX_DELAY);

    int w = g_image_snapshot.width;
    int h = g_image_snapshot.height;

    static uint8_t *rgb_buf = NULL;
    static size_t rgb_size = 0;

    if (rgb_size < w * h * 3) {
        free(rgb_buf);
        rgb_buf = malloc(w * h * 3);
        rgb_size = w * h * 3;
    }

    grayscale_to_rgb888(g_image_snapshot.buf, rgb_buf, w, h);
    draw_roi_rect_rgb(rgb_buf, w, h, &g_roi);
    draw_centroid_rgb(rgb_buf, w, h, &g_target, 1);
    draw_centroid_rgb(rgb_buf, w, h, &g_centroid, 2);

    // bool ok = fmt2jpg(
    //     g_image_snapshot.buf,
    //     g_image_snapshot.len,
    //     g_image_snapshot.width,
    //     g_image_snapshot.height,
    //     PIXFORMAT_GRAYSCALE,
    //     80,
    //     &jpg_buf,
    //     &jpg_len
    // );

    xSemaphoreGive(g_image_mutex);

    bool ok = fmt2jpg(
        rgb_buf,
        w * h * 3,
        w,
        h,
        PIXFORMAT_RGB888,
        80,
        &jpg_buf,
        &jpg_len
    );

    if (!ok) {
        httpd_resp_send_500(req);
        return ESP_FAIL;
    }

    httpd_resp_set_type(req, "image/jpeg");
    httpd_resp_send(req, (const char *)jpg_buf, jpg_len);

    free(jpg_buf);
    return ESP_OK;
}

// ========================
// HTTP SERVER
// ========================
esp_err_t http_api_start(void) {

    ESP_ERROR_CHECK(spiffs_mount());

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.lru_purge_enable = true;
    config.max_open_sockets = 6;
    config.stack_size = 8192;

    ESP_LOGI(TAG, "Starting API server on port %d", config.server_port);
    if (httpd_start(&g_api_server, &config) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to start API server");
        return ESP_FAIL;
    }

    httpd_uri_t uri_index = {
        .uri="/",
        .method=HTTP_GET,
        .handler=index_handler
    };
    httpd_uri_t uri_appjs = {
        .uri="/app.js",
        .method=HTTP_GET,
        .handler=appjs_handler
    };
    httpd_uri_t uri_style = {
        .uri="/style.css",
        .method=HTTP_GET,
        .handler=style_handler
    };
    httpd_uri_t uri_status = {
        .uri = "/status",
        .method = HTTP_GET,
        .handler = status_handler
    };
    httpd_uri_t uri_control = {
        .uri = "/control",
        .method = HTTP_GET,
        .handler = control_handler
    };
    httpd_uri_t uri_preview = {
        .uri = "/preview",
        .method = HTTP_GET,
        .handler = preview_handler
    };
    httpd_uri_t uri_roi = {
        .uri = "/roi",
        .method = HTTP_GET,
        .handler = roi_handler
    };
    httpd_uri_t uri_target = {
        .uri = "/target",
        .method = HTTP_GET,
        .handler = target_handler
    };

    httpd_register_uri_handler(g_api_server, &uri_index);
    httpd_register_uri_handler(g_api_server, &uri_appjs);
    httpd_register_uri_handler(g_api_server, &uri_style);
    httpd_register_uri_handler(g_api_server, &uri_status);
    httpd_register_uri_handler(g_api_server, &uri_control);
    httpd_register_uri_handler(g_api_server, &uri_preview);
    httpd_register_uri_handler(g_api_server, &uri_roi);
    httpd_register_uri_handler(g_api_server, &uri_target);

    return ESP_OK;
}